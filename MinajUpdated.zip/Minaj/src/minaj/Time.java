package minaj;

public class Time {
    public String date;
    public String startTime;
    public String endTime;
    public int id;
    
    public Time (String date, String startTime, String endTime, int id) {
       this.date = date;
       this.startTime = startTime;
       this.endTime = endTime;
       this.id = id;
    }

    public String getDate() {
       return date;
    }

    public String getStartTime() {
       return startTime;
    }

    public String getEndTime() {
       return endTime;
    }

    public int getId() {
       return id;
    }
 }
