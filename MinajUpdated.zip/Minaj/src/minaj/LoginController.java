package minaj;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import javax.swing.JOptionPane;
import static minaj.Minaj.*;
import static minaj.Minaj.stage;

public class LoginController implements Initializable {

    private Label statusLbl;
    @FXML
    private JFXTextField userIdTextBox;
    @FXML
    private JFXPasswordField passwordTextBox;
    @FXML
    private Button loginBtn;
    @FXML
    private Label lbl_newUser;
    @FXML
    private FontAwesomeIcon passwordView;
    @FXML
    private FontAwesomeIcon passwordView1;
    @FXML
    private JFXButton close;

    ScaleTransition st = null;
    int flag = 0;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setLoginBtn();
    }

    private void registrationProcess(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("RegistrationFXML.fxml"));
            stage.setTitle("Minaj Proj");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @FXML
    private void NewRegisterUI(MouseEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("RegistrationFXML.fxml"));
            stage.setTitle("Minaj Proj");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }

    private void setLoginBtn() {
        HBox hBox = new HBox();
        Label label = new Label("Submit");
        label.getStyleClass().add("submit-label");
        hBox.setSpacing(5);
        ImageView image1 = new ImageView(getClass().getResource("Photos/ludoDiceBlue.png").toExternalForm());
        ImageView image2 = new ImageView(getClass().getResource("Photos/ludoDiceRed.png").toExternalForm());
        label.setMaxWidth(Long.MAX_VALUE);

        HBox.setHgrow(label, Priority.ALWAYS);

        hBox.getChildren().addAll(image1, label, image2);

        loginBtn.setGraphic(hBox);

        RotateTransition rotationBlue = new RotateTransition(Duration.seconds(0.5), image1);
        rotationBlue.setCycleCount(Animation.INDEFINITE);
        rotationBlue.setByAngle(360);

        RotateTransition rotationRed = new RotateTransition(Duration.seconds(0.5), image2);
        rotationRed.setCycleCount(Animation.INDEFINITE);
        rotationRed.setByAngle(360);

        loginBtn.setOnMouseEntered(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                loginBtn.setCursor(Cursor.OPEN_HAND);
                rotationBlue.play();
                rotationRed.play();
            }
        });
        loginBtn.setOnMouseExited(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                loginBtn.setCursor(Cursor.OPEN_HAND);
                rotationBlue.pause();
                rotationRed.pause();
            }
        });
        loginBtn.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginBtn.setCursor(Cursor.CLOSED_HAND);
            }

        });
        loginBtn.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginBtn.setCursor(Cursor.OPEN_HAND);
            }
        });

        //******************Not need to edit anything till here from previous comment**************************//
        loginBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (flag == 0) {
                    st = new ScaleTransition(Duration.millis(400), loginBtn);
                    st.setByX(0.1f);
                    st.setByY(0.1f);
                    st.setCycleCount(2);
                    st.setAutoReverse(true);
                    flag = 1;
                    st.onFinishedProperty().set(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent actionEvent) {
                            flag = 0;
                            String userName = userIdTextBox.getText();
                            String userPassword = passwordTextBox.getText();

                            //Verifying here with the credentials entered by thge user
                            try { //try different functions here
                                Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj", user, pass);//connect to db
                                int id = DatabaseQueries.submitLogin(conn, userName, userPassword);

                                if (id > 0) {

                                    Scene scene = new Scene(new Group());
                                    stage.setTitle("Table View Sample");
                                    stage.setWidth(700);
                                    stage.setHeight(600);

                                    EmployeeTable.setEditable(true);
                                    InventoryTable.setEditable(true);
                                    TimeTable.setEditable(true);
                                    ManagersTable.setEditable(true);

                                    EmployeeTable.setMinWidth(620);
                                    InventoryTable.setMinWidth(620);
                                    TimeTable.setMinWidth(620);
                                    ManagersTable.setMinWidth(620);

                                    EmployeeTable.setMaxHeight(250);
                                    InventoryTable.setMaxHeight(250);
                                    TimeTable.setMaxHeight(250);
                                    ManagersTable.setMaxHeight(250);

                                    TableColumn<Employee, Integer> EmployeeId = new TableColumn("Employee ID");
                                    EmployeeId.setCellValueFactory(new PropertyValueFactory<>("id"));
                                    TableColumn<Employee, String> firstNameColEmployee = new TableColumn("First Name");
                                    firstNameColEmployee.setCellValueFactory(new PropertyValueFactory<>("firstName"));
                                    TableColumn<Employee, String> lastNameColEmployee = new TableColumn("Last Name");
                                    lastNameColEmployee.setCellValueFactory(new PropertyValueFactory<>("lastName"));
                                    TableColumn<Employee, String> phoneNumberCol = new TableColumn("Phone Number");
                                    phoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
                                    TableColumn<Employee, String> emailCol = new TableColumn("Email");
                                    emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
                                    TableColumn<Employee, String> positionCol = new TableColumn("Position");
                                    positionCol.setCellValueFactory(new PropertyValueFactory<>("position"));
                                    TableColumn<Employee, String> addressCol = new TableColumn("Address");
                                    addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
                                    EmployeeTable.getColumns().addAll(
                                            EmployeeId,
                                            firstNameColEmployee,
                                            lastNameColEmployee,
                                            phoneNumberCol,
                                            emailCol,
                                            positionCol,
                                            addressCol
                                    );

                                    TableColumn<Inventory, Integer> nameCol = new TableColumn("Name");
                                    nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
                                    TableColumn<Inventory, Integer> count = new TableColumn("Count");
                                    count.setCellValueFactory(new PropertyValueFactory<>("count"));
                                    InventoryTable.getColumns().addAll(nameCol, count);

                                    TableColumn<Time, String> date = new TableColumn("Date");
                                    date.setCellValueFactory(new PropertyValueFactory<>("date"));
                                    TableColumn<Time, String> startTime = new TableColumn("Start Time");
                                    startTime.setCellValueFactory(new PropertyValueFactory<>("startTime"));
                                    TableColumn<Time, String> endTime = new TableColumn("End Time");
                                    endTime.setCellValueFactory(new PropertyValueFactory<>("endTime"));
                                    TableColumn<Time, Integer> employeeId = new TableColumn("Employee ID");
                                    employeeId.setCellValueFactory(new PropertyValueFactory<>("id"));
                                    TimeTable.getColumns().addAll(date, startTime, endTime, employeeId);

                                    TableColumn<Manager, Integer> managerId = new TableColumn("Manager ID");
                                    managerId.setCellValueFactory(new PropertyValueFactory<>("id"));
                                    TableColumn<Manager, String> firstNameColManager = new TableColumn("First Name");
                                    firstNameColManager.setCellValueFactory(new PropertyValueFactory<>("firstName"));
                                    TableColumn<Manager, String> lastNameColManager = new TableColumn("Last Name");
                                    lastNameColManager.setCellValueFactory(new PropertyValueFactory<>("lastName"));
                                    ManagersTable.getColumns().addAll(managerId, firstNameColManager, lastNameColManager);

                                    try { //try different functions here
                                        conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/minaj", user, pass);//connect to db

                                        List<Object[]> employees = DatabaseQueries.getEmployees(conn);
                                        for (Object[] employee : employees) {
                                            EmployeeTable.getItems().add(new Employee(
                                                    (Integer) employee[0],
                                                    (String) employee[1],
                                                    (String) employee[2],
                                                    (String) employee[3],
                                                    (String) employee[4],
                                                    (String) employee[5],
                                                    (String) employee[6]
                                            // employee[7]
                                            ));
                                        }

                                        List<Object[]> inventory = DatabaseQueries.getInventory(conn);
                                        for (Object[] item : inventory) {
                                            InventoryTable.getItems().add(new Inventory(
                                                    (Integer) item[0],
                                                    (String) item[1],
                                                    (Integer) item[2]
                                            ));
                                        }

//        List<Object[]> times = DatabaseQueries.getTime(conn);
//        for (Object[] time: times) {
//            TimeTable.getItems().add(new Time(
//                (String) time[0],
//                (String) time[1],
//                (String) time[2],
//                (Integer)time[3]
//            ));
//        }
                                        // getUsers(conn)
                                        conn.close();
                                    } catch (SQLException e) {
                                        e.printStackTrace();
                                    }

                                    Text text = new Text();
                                    text.setFont(new Font(14));
                                    String message = "Enter comma separated values with no spaces. after the comma \n";
                                    message += ", there should be as many values as there are columns in order";
                                    text.setText(message);

                                    Tab employeeTab = new Tab("Employee");
                                    Tab inventoryTab = new Tab("Inventory");
                                    Tab timeTab = new Tab("Time");
                                    Tab managersTab = new Tab("Managers");

                                    employeeTab.setContent(EmployeeTable);
                                    inventoryTab.setContent(InventoryTable);
                                    timeTab.setContent(TimeTable);
                                    managersTab.setContent(ManagersTable);

                                    tabPane.getTabs().add(employeeTab);
                                    tabPane.getTabs().add(inventoryTab);
                                    tabPane.getTabs().add(timeTab);
                                    tabPane.getTabs().add(managersTab);

                                    tabPane.setStyle("-fx-pref-width: 450");

                                    final VBox vbox = new VBox(Minaj.filterField(), filterResetButton(), tabPane, text, textFields(), addRemove());
                                    vbox.setSpacing(5);
                                    vbox.setMinWidth(670);
                                    vbox.setPadding(new Insets(10, 0, 0, 10));
                                    vbox.getChildren().addAll(EmployeeTable, InventoryTable, TimeTable, ManagersTable);

                                    ((Group) scene.getRoot()).getChildren().addAll(vbox);

                                    stage.setScene(scene);
                                    stage.show();
                                } else {
                                    JOptionPane.showMessageDialog(null, "Invalid login please try again");
                                }
                                conn.close();
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    st.play();
                }
            }
        }
        );
    }

    @FXML
    private void closeAction(ActionEvent event) {
        System.exit(0);
    }
}
