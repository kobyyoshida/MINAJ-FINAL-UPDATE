package minaj;

public class Manager {

    private int id = -1;
    private String firstName = null;
    private String lastName = null;

    public Manager(int id, String firstName, String lastName) {
       this.id = id;
       this.firstName = firstName;
       this.lastName = lastName;
    }

    public int getId() {
       return id;
    } 

    public String getFirstName() {
       return firstName;
    }

    public String getLastName() {
       return lastName;
    }
 }