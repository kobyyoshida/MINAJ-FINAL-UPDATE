package minaj;

public class Inventory {
    private int id = -1;
    private String name = null;
    private int count = -1;

    public Inventory(int id, String name, int count) {
       this.id = id;
       this.name = name;
       this.count = count;
    }

    public int getId() {
        return id;
    }

    public String getName() {
       return name;
    }

    public int getCount() {
       return count;
    }
 }