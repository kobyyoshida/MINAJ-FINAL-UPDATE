package minaj;

import javafx.application.Application;
import javafx.stage.Stage;
import java.sql.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import static javafx.application.Application.launch;

/**
 *
 * @author Koby
 */
public class DatabaseQueries extends Application {

    static String user = "root";
    static String pass = "chapman123";

    @Override
    public void start(Stage primaryStage) {
        System.out.println("Starting application");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //find driver leave this try catch alone
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

        } catch (Exception e) {

        }

        try { //try different functions here
            Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj", user, pass);//connect to db

            System.out.println("GET EMPLOYEES FXN: " + getEmployees(conn)); // [Employee ID, FirstName, LastName, PhoneNumber, Email, Position, Address, UserID]
            System.out.println("GET INVENTORY FXN: " + getInventory(conn)); //[ItemID, ItemName, Count]
            System.out.println("GET EVENTS FXN: " + getEvents(conn, 1)); // [Name, Description, DateTime, UserID]
            System.out.println("GET TIME FXN: " + getTime(conn, 1)); // [Date, StartTime, EndTime, EmployeeID]
            System.out.println("GET USERS FXN: " + getUsers(conn, 1)); //[UserID, Username, Password, Email, isEmployee]

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        launch(args);
    }

    //https://www.geeksforgeeks.org/md5-hash-in-java/
    public static String getMd5(String input) {
        try {

            // Static getInstance method is called with hashing MD5 
            MessageDigest md = MessageDigest.getInstance("MD5");

            // digest() method is called to calculate message digest 
            //  of an input digest() return array of byte 
            byte[] messageDigest = md.digest(input.getBytes());

            // Convert byte array into signum representation 
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value 
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public static List getEmployees(Connection conn) {// select * from Employees table
        Statement stmt = null;
        ResultSet rs = null;
        String finalResult = null;
        List<Object[]> resultList = new ArrayList<Object[]>();//List created to hold different object types for tommys merge
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM Employees");
            while (rs.next()) {
                Object[] currentUser = {
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getInt(8)
                };
                resultList.add(currentUser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (resultList);
    }

    public static List getInventory(Connection conn) { // Select all from Inventory table
        Statement stmt = null;
        ResultSet rs = null;
        String finalResult = null;
        List<Object[]> resultList = new ArrayList<Object[]>();//List created to hold different object types for tommys merge
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM Inventory");

            while (rs.next()) {
                //finalResult = "Inventory item: "+ rs.getString(1)+ " "+ rs.getString(2) + " "+ rs.getString(3);
                //System.out.println("GET Inventory 2:"+finalResult);
                Object[] currentInventory = {
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getInt(3)
                };
                resultList.add(currentInventory);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (resultList);
    }

    public static List getEvents(Connection conn, int userid) { // select * from Events table
        Statement stmt = null;
        ResultSet rs = null;
        String finalResult = null;
        List<Object> resultList = new ArrayList<Object>();//List created to hold different object types for tommys merge

        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM Events WHERE UserID = " + userid);

            while (rs.next()) {
                //finalResult = "Event: "+ rs.getString(1)+ " "+ rs.getString(2) + " "+ rs.getString(3) + " "+ rs.getString(4);
                //System.out.println("getEvent():"+finalResult);
                resultList.add(rs.getString(1));
                resultList.add(rs.getString(2));
                resultList.add(rs.getString(3));
                resultList.add(rs.getInt(4));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (resultList);
    }

    public static List getTime(Connection conn, int userid) { // select * from Time table
        Statement stmt = null;
        ResultSet rs = null;
        String finalResult = null;
        List<Object[]> resultList = new ArrayList<Object[]>();//List created to hold different object types for tommys merge
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM Time WHERE EmployeeID = " + userid);

            while (rs.next()) {
                //finalResult = "Time: "+ rs.getString(1)+ " "+ rs.getString(2) + " "+ rs.getString(3) + " "+ rs.getString(4);
                //System.out.println("getTime():"+finalResult);
                Object[] currentTime = {
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getInt(4)
                };
                resultList.add(currentTime);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (resultList);
    }

    public static List getUsers(Connection conn, int userid) { // select * from Users table
        Statement stmt = null;
        ResultSet rs = null;
        String finalResult = null;
        List<Object> resultList = new ArrayList<Object>();//List created to hold different object types for tommys merge

        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM Users");

            while (rs.next()) {

                resultList.add(rs.getInt(1));
                resultList.add(rs.getString(2));
                resultList.add(rs.getString(3));
                resultList.add(rs.getString(4));
                resultList.add(rs.getInt(5));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (resultList);
    }

    public static int insertNewEmployee(Connection conn, String first_name, String last_name, String phone_number, String email, String position, String address, int userid) { // insert into employees table
        String sql = "INSERT INTO Employees (FirstName, LastName, PhoneNumber, Email, Position, Address, UserID)" + "VALUES (?,?,?,?,?,?,?)";

        try {

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, first_name);
            statement.setString(2, last_name);
            statement.setString(3, phone_number);
            statement.setString(4, email);
            statement.setString(5, position);
            statement.setString(6, address);
            statement.setInt(7, userid);
            statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return getEmployeeID(conn, first_name, last_name);
    }

    public static int insertNewUser(Connection conn, String username, String password, String emailAddress, Boolean isEmployee) { // insert into users table
        String sql = "INSERT INTO Users (Username, Password, Email, isEmployee)" + "VALUES (?,?,?,?)";
        //password = getMD5(password);

        try {

            PreparedStatement statement = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, username);
            statement.setString(2, password); //convert password to hash
            statement.setString(3, emailAddress);
            statement.setBoolean(4, isEmployee);
            int rowAffected = statement.executeUpdate();

            int candidateId = 0;
            ResultSet rs = statement.getGeneratedKeys();
            if (rs.next()) {
                candidateId = rs.getInt(1);
            }
            System.out.println(candidateId);

            return candidateId;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static int insertNewInventory(Connection conn, String itemName, int count, int userid) {
        String sql = "INSERT INTO Inventory (ItemName, Count, User)" + "VALUES (?,?,?)";
        //password = getMD5(password);

        try {

            PreparedStatement statement = conn.prepareStatement(sql);
            //statement.setInt(1,0);
            statement.setString(2, itemName); //convert password to hash
            statement.setInt(3, count);
            statement.setInt(4, userid);

            statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return getInventoryID(conn, itemName);
    }

    public static int getInventoryID(Connection conn, String itemName) {
        String sql = "SELECT ItemID FROM Inventory WHERE ItemName = <item>";
        sql = sql.replace("<item>", itemName);
        //sql = sql.replace("<userNum>",userid);
        ResultSet rs = null;
        int itemID = 0;

        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            rs = statement.executeQuery(sql);

            while (rs.next()) {
                itemID = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return itemID;
    }

    public static void insertNewShift(Connection conn, String date, String start_time, String end_time, int employee_id, int userid) {
        //Enter start/end time in MILITARY TIME (ex: 1:30PM = 13:30PM)to satisfy constraints
        String sql = "INSERT INTO Time (Date, StartTime, EndTime, EmployeeID)" + "VALUES (?,?,?,?)";

        try {

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, date);
            statement.setString(2, start_time);
            statement.setString(3, end_time);
            statement.setInt(4, employee_id);
            statement.setInt(5, userid);

            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void insertEvent(Connection conn, String name, String description, String date, String time, int userID) {
        String sql = "INSERT INTO Events (Name, Description, Date, Time, UserID)" + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, description);
            statement.setString(3, date);
            statement.setString(4, time);
            statement.setInt(5, userID);

            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int getEmployeeID(Connection conn, String first_name, String last_name) { // gets employee ID based on first/last name
        String sql = "SELECT EmployeeID FROM Employees WHERE FirstName = <firstname> AND LastName = <lastname>";
        sql = sql.replace("<firstname>", first_name);
        sql = sql.replace("<lastname>", last_name);
        ResultSet rs = null;
        int uID = 0;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            rs = statement.executeQuery(sql);

            while (rs.next()) {
                uID = rs.getInt(5);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uID;
    }

    public static int submitLogin(Connection conn, String username, String password) { //returns ID if username/password exists

        String sql = "SELECT UserID FROM Users WHERE Username = '" + username + "' AND Password = '" + password + "'";
        //sql.replace("<user>","koyoshida");
        //sql.replace("<pass>","password");
        //System.out.println("SQL = " + sql);

        ResultSet rs = null;
        int id = 0;

        try {
            //conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/minaj", user, pass);
            PreparedStatement statement = conn.prepareStatement(sql);
            rs = statement.executeQuery(sql);
            while (rs.next()) {
                id = rs.getInt(1);
            }
            //id = rs.getInt("UserID");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("ID NUMBER:" + id);
        return id;
    }

    public static void deleteEmployee(Connection conn, int employeeID) {
        String sql = "DELETE FROM Employees WHERE EmployeeID = " + employeeID;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static void deleteEvent(Connection conn, String eventName) {
        String sql = "DELETE FROM Events WHERE Name = " + eventName;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void deleteInventoryItem(Connection conn, String itemID) {//delete entire inventory item
        String sql = "DELETE FROM Inventory WHERE ItemID = " + itemID;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void deleteShift(Connection conn, String date, String startTime, String endTime) { //delete a shift from time table based on date/time
        String sql = "DELETE FROM Time WHERE Date = " + date + " AND StartTime = " + startTime + " AND EndTime = " + endTime;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void deleteUser(Connection conn, String userID) {
        String sql = "DELETE FROM Users WHERE UserID = " + userID;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

//    public static int submitLogin(String username, String password) { //returns ID if username/password exists
//
//        String sql = "SELECT UserID FROM Users WHERE Username = '" + username + "' AND Password = '" + getMd5(password) + "'";
//        //sql.replace("<user>","koyoshida");
//        //sql.replace("<pass>","password");
//        System.out.println("SQL = " + sql);
//
//        ResultSet rs = null;
//        int id = 0;
//
//        try {
//            Connection _conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj", user, pass);
//            PreparedStatement statement = _conn.prepareStatement(sql);
//            rs = statement.executeQuery(sql);
//            while (rs.next()) {
//                id = rs.getInt(1);
//            }
//            //id = rs.getInt("UserID");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println("ID NUMBER:" + id);
//        return id;
//    }
//
//    public static void deleteEmployee(Connection conn, int employeeID) {
//        String sql = "DELETE FROM Employees WHERE EmployeeID = " + employeeID;
//        try {
//            PreparedStatement statement = conn.prepareStatement(sql);
//            statement.executeUpdate(sql);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//
//    public static void deleteEvent(Connection conn, String eventName) {
//        String sql = "DELETE FROM Events WHERE Name = " + eventName;
//        try {
//            PreparedStatement statement = conn.prepareStatement(sql);
//            statement.executeUpdate(sql);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//
//    public static void deleteInventoryItem(Connection conn, String itemID) {//delete entire inventory item
//        String sql = "DELETE FROM Inventory WHERE ItemID = " + itemID;
//        try {
//            PreparedStatement statement = conn.prepareStatement(sql);
//            statement.executeUpdate(sql);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//
//    public static void deleteShift(Connection conn, String date, String startTime, String endTime) { //delete a shift from time table based on date/time
//        String sql = "DELETE FROM Time WHERE Date = " + date + " AND StartTime = " + startTime + " AND EndTime = " + endTime;
//        try {
//            PreparedStatement statement = conn.prepareStatement(sql);
//            statement.executeUpdate(sql);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//
//    public static void deleteUser(Connection conn, String userID) {
//        String sql = "DELETE FROM Users WHERE UserID = " + userID;
//        try {
//            PreparedStatement statement = conn.prepareStatement(sql);
//            statement.executeUpdate(sql);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//}
//
//private void addButtonClicked() {
//
//        if (!(input.getText() == null || "".equals(input.getText().trim()))) {
//           String currentTab = tabPane.getSelectionModel().getSelectedItem().getText();
//           String[] values = input.getText().split(",");
//  
//           try{
//            if (currentTab == "Employee") {
//                EmployeeTable.getItems().add(new Employee(
//                    80,
//                    values[0], 
//                    values[1], 
//                    values[2],
//                    values[3],
//                    values[4],
//                    values[5]
//                ));
//                Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj",user,pass);
//                insertNewEmployee(
//                conn,
//                values[0], 
//                values[1], 
//                values[2],
//                values[3],
//                values[4],
//                values[5]
//                );
//            } else if (currentTab == "Inventory") {
//                // InventoryTable.getItems().add(new Inventory(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
//            } else if (currentTab == "Time") {
//                // TimeTable.getItems().add(new Time(values[0], values[1], Integer.parseInt(values[2])));
//            } 
//        }
//        catch(Exception e){
//            System.out.println(e);
//        }
//           input.clear();
//        }
//     }
//  
//     private void filterSubmitClicked() {
//        if (!(filter.getText() == null || "".equals(filter.getText().trim()))) {
//           String currentTab = tabPane.getSelectionModel().getSelectedItem().getText();
//           String value = filter.getText();
//  
//           if (currentTab == "Employee") {
//              ObservableList originalValues = FXCollections.observableArrayList(EmployeeTable.getItems());
//              employeesReset = originalValues;
//              EmployeeTable.getItems().clear();
//              for (Object e : originalValues) {
//                 Employee employee = (Employee) e;
//                 String firstName = employee.getFirstName();
//                 String lastName = employee.getLastName();
//                 System.out.println(value);
//                 String stringId = Integer.toString(employee.getId());
//                 if (firstName.contains(value) || lastName.contains(value) || stringId.contains(value)) {
//                    EmployeeTable.getItems().add(employee);
//                 }
//              }
//              
//           } else if (currentTab == "Inventory") {
//              // InventoryTable.getItems().add(new Inventory(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
//           } else if (currentTab == "Time") {
//              // TimeTable.getItems().add(new Time(values[0], values[1], Integer.parseInt(values[2])));
//           } 
//           filter.clear();
//        }
//     }
//  
//     private void deleteButtonClicked() {
//        String currentTab = tabPane.getSelectionModel().getSelectedItem().getText();
//        if (currentTab == "Employee") {
//            try{
//                Employee employeeToDelete = (Employee) EmployeeTable.getSelectionModel().getSelectedItems().get(0);
//                Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj",user,pass);
//                deleteEmployee(conn, employeeToDelete.getId());
//            }
//            catch(Exception e){
//                System.out.println(e);
//            }
//            
//           EmployeeTable.getItems().removeAll(
//              EmployeeTable.getSelectionModel().getSelectedItems()
//        );
//        
//            
//        } else if (currentTab == "Inventory") {
//           InventoryTable.getItems().removeAll(
//              InventoryTable.getSelectionModel().getSelectedItems()
//        );
//        } else if (currentTab == "Time") {
//              TimeTable.getItems().removeAll(
//                 TimeTable.getSelectionModel().getSelectedItems()
//           );
//        }
//     }
//  
//     private HBox filterField() {
//        filter = new TextField();
//        filter.setPromptText("Filter");
//        filter.setMinWidth(75);
//  
//        HBox hBox = new HBox();
//        hBox.setPadding(new Insets(10, 10, 10, 10));
//        hBox.setSpacing(10);
//        hBox.getChildren().addAll(filter);
//  
//        return hBox;
//    }
//  
//     private HBox textFields() {
//        input = new TextField();
//        input.setPromptText("Input");
//        input.setMinWidth(75);
//  
//        HBox hBox = new HBox();
//        hBox.setPadding(new Insets(10, 10, 10, 10));
//        hBox.setSpacing(10);
//        hBox.getChildren().addAll(input);
//  
//        return hBox;
//    }
//  
//    private void resetButtonClicked() {
//       if (employeesReset.size() != 0) {
//        EmployeeTable.getItems().clear();
//        for (Object e : employeesReset) {
//           Employee employee = (Employee) e;
//           String firstName = employee.getFirstName();
//           String lastName = employee.getLastName();
//           String stringId = Integer.toString(employee.getId());
//           EmployeeTable.getItems().add(employee);
//        }
//       }
//    }
//    private HBox filterResetButton() {
//     Button filterSubmit = new Button("Filter");
//     filterSubmit.setOnAction(e -> filterSubmitClicked());
//     Button resetButton = new Button("Reset");
//     resetButton.setOnAction(e -> resetButtonClicked());
//     HBox hBox2 = new HBox(
//             10,
//             filterSubmit,
//             resetButton
//     );
//     hBox2.setPadding(new Insets(10, 10, 10, 10));
//  
//     return hBox2;
//  }
//  
//     private HBox addRemove() {
//        Button addButton = new Button("Add");
//        addButton.setOnAction(e -> addButtonClicked());
//        Button deleteButton = new Button("Delete");
//        deleteButton.setOnAction(e -> deleteButtonClicked());
//        HBox hBox2 = new HBox(
//                10,
//                addButton, deleteButton
//        );
//        hBox2.setPadding(new Insets(10, 10, 10, 10));
//        hBox2.setSpacing(10);
//  
//        return hBox2;
//    }
}
