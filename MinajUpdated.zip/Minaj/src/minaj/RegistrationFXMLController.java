/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minaj;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javax.swing.JOptionPane;
import static minaj.Minaj.*;

/**
 * FXML Controller class
 *
 * @author Terminator
 */
public class RegistrationFXMLController implements Initializable {

    @FXML
    private JFXButton registrationCloseBtn;
    @FXML
    private JFXTextField registrationName;
    @FXML
    private JFXTextField registrationEmail;
    @FXML
    private JFXPasswordField registrationPasswordField;
    @FXML
    private JFXPasswordField registrationRePasswordField;
    @FXML
    private JFXButton registrationSubmit;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void registrationClose(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("loginScreen.fxml"));
            Scene scene = new Scene(root);
            Minaj.stage.setScene(scene);
            Minaj.stage.setMaximized(false);
            Minaj.stage.centerOnScreen();
            Minaj.stage.show();

        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @FXML
    private void registerMember(ActionEvent event) {
        String name = registrationName.getText().trim();
        String email = registrationEmail.getText().trim();

        String passPhrase = registrationPasswordField.getText();
        String passRe = registrationRePasswordField.getText();
        if (!name.equals("")) {
            if (!email.equals("")) {
                if (passPhrase.equals(passRe)) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj", user, pass);//connect to db

                        int result = DatabaseQueries.insertNewUser(conn, name, passPhrase, email, Boolean.TRUE);

                        if (result > 0) {
                            JOptionPane.showMessageDialog(null, "Registered Successfully");
                            try {
                                Parent root = FXMLLoader.load(getClass().getResource("loginScreen.fxml"));
                                Scene scene = new Scene(root);
                                Minaj.stage.setScene(scene);
                                Minaj.stage.setMaximized(false);
                                Minaj.stage.centerOnScreen();
                                Minaj.stage.show();

                            } catch (IOException ex) {
                                System.err.println(ex.getMessage());
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Unsuccessful attempt plz retry");
                            try {
                                Parent root = FXMLLoader.load(getClass().getResource("registrationFXML.fxml"));
                                Scene scene = new Scene(root);
                                Minaj.stage.setScene(scene);
                                Minaj.stage.setMaximized(false);
                                Minaj.stage.centerOnScreen();
                                Minaj.stage.show();

                            } catch (IOException ex) {
                                System.err.println(ex.getMessage());
                            }
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(RegistrationFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Retyped Password not matched");
                }

            } else {
                JOptionPane.showMessageDialog(null, "Email is required");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Name is required");
        }

    }

}
