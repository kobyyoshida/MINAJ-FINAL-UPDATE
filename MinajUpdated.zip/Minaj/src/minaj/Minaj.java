package minaj;

import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.collections.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
//import org.json.*;

/**
 *
 * @author Koby
 */
public class Minaj extends Application {

    static String user = "root";
    static String pass = "chapman123";

    public static TableView EmployeeTable = new TableView();
    public static TableView InventoryTable = new TableView();
    public static TableView TimeTable = new TableView();
    public static TableView ManagersTable = new TableView();
    public static TextField input, filter;
    public static ObservableList employeesReset;
    public static TabPane tabPane = new TabPane();
    
    public static Stage stage= null;
    // private TableView UsersTable = new TableView();

    // @Override
    // public void start(Stage primaryStage) {
    //     System.out.println("Starting application");
    // }
    @Override
    public void start(Stage stage) {
        try {
            this.stage = stage;
            Parent root = FXMLLoader.load(getClass().getResource("loginScreen.fxml"));
            stage.setTitle("Minaj Proj");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Minaj.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void addButtonClicked() {

        if (!(input.getText() == null || "".equals(input.getText().trim()))) {
            String currentTab = tabPane.getSelectionModel().getSelectedItem().getText();
            String[] values = input.getText().split(",");

            try {
                if (null != currentTab) {
                    switch (currentTab) {
                        case "Employee":
                            EmployeeTable.getItems().add(new Employee(
                                    80,
                                    values[0],
                                    values[1],
                                    values[2],
                                    values[3],
                                    values[4],
                                    values[5]
                            ));
//                Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj",user,pass);
//                DatabaseQueries.insertNewEmployee(
//                conn,
//                values[0],
//                values[1], 
//                values[2],
//                values[3],
//                values[4],
//                values[5]
//                );
                            break;
                        // InventoryTable.getItems().add(new Inventory(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
                        case "Inventory":
                            break;
                        // TimeTable.getItems().add(new Time(values[0], values[1], Integer.parseInt(values[2])));
                        case "Time":
                            break;
                        default:
                            break;
                    }
                }
            } catch (Exception e) {
                System.out.println(e);
            }
            input.clear();
        }
    }

    public static void filterSubmitClicked() {
        if (!(filter.getText() == null || "".equals(filter.getText().trim()))) {
            String currentTab = tabPane.getSelectionModel().getSelectedItem().getText();
            String value = filter.getText();

            if (null != currentTab) {
                switch (currentTab) {
                    case "Employee":
                        ObservableList originalValues = FXCollections.observableArrayList(EmployeeTable.getItems());
                        employeesReset = originalValues;
                        EmployeeTable.getItems().clear();
                        for (Object e : originalValues) {
                            Employee employee = (Employee) e;
                            String firstName = employee.getFirstName();
                            String lastName = employee.getLastName();
                            System.out.println(value);
                            String stringId = Integer.toString(employee.getId());
                            if (firstName.contains(value) || lastName.contains(value) || stringId.contains(value)) {
                                EmployeeTable.getItems().add(employee);
                            }
                        }
                        break;
                    // InventoryTable.getItems().add(new Inventory(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
                    case "Inventory":
                        break;
                    // TimeTable.getItems().add(new Time(values[0], values[1], Integer.parseInt(values[2])));
                    case "Time":
                        break;
                    default:
                        break;
                }
            }
            filter.clear();
        }
    }

    public static void deleteButtonClicked() {
        String currentTab = tabPane.getSelectionModel().getSelectedItem().getText();
        if (null != currentTab) {
            switch (currentTab) {
                case "Employee":
                    try {
                        Employee employeeToDelete = (Employee) EmployeeTable.getSelectionModel().getSelectedItems().get(0);
                        Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj", user, pass);
                        DatabaseQueries.deleteEmployee(conn, employeeToDelete.getId());
                    } catch (SQLException e) {
                        System.out.println(e);
                    }
                    EmployeeTable.getItems().removeAll(
                            EmployeeTable.getSelectionModel().getSelectedItems()
                    );
                    break;
                case "Inventory":
                    InventoryTable.getItems().removeAll(
                            InventoryTable.getSelectionModel().getSelectedItems()
                    );
                    break;
                case "Time":
                    TimeTable.getItems().removeAll(
                            TimeTable.getSelectionModel().getSelectedItems()
                    );
                    break;
                default:
                    break;
            }
        }
    }

    public static HBox filterField() {
        filter = new TextField();
        filter.setPromptText("Filter");
        filter.setMinWidth(75);

        HBox hBox = new HBox();
        hBox.setPadding(new Insets(10, 10, 10, 10));
        hBox.setSpacing(10);
        hBox.getChildren().addAll(filter);

        return hBox;
    }

    public static HBox textFields() {
        input = new TextField();
        input.setPromptText("Input");
        input.setMinWidth(75);

        HBox hBox = new HBox();
        hBox.setPadding(new Insets(10, 10, 10, 10));
        hBox.setSpacing(10);
        hBox.getChildren().addAll(input);

        return hBox;
    }

    public static void resetButtonClicked() {
        if (!employeesReset.isEmpty()) {
            EmployeeTable.getItems().clear();
            for (Object e : employeesReset) {
                Employee employee = (Employee) e;
                String firstName = employee.getFirstName();
                String lastName = employee.getLastName();
                String stringId = Integer.toString(employee.getId());
                EmployeeTable.getItems().add(employee);
            }
        }
    }

    public static HBox filterResetButton() {
        Button filterSubmit = new Button("Filter");
        filterSubmit.setOnAction(e -> filterSubmitClicked());
        Button resetButton = new Button("Reset");
        resetButton.setOnAction(e -> resetButtonClicked());
        HBox hBox2 = new HBox(
                10,
                filterSubmit,
                resetButton
        );
        hBox2.setPadding(new Insets(10, 10, 10, 10));

        return hBox2;
    }

    public static HBox addRemove() {
        Button addButton = new Button("Add");
        addButton.setOnAction(e -> addButtonClicked());

        Button deleteButton = new Button("Delete");

        HBox hBox2 = new HBox(
                10,
                addButton, deleteButton
        );
        deleteButton.setOnAction(e -> deleteButtonClicked());
        hBox2.setPadding(new Insets(10, 10, 10, 10));
        hBox2.setSpacing(10);

        return hBox2;
    }

    public static void main(String[] args) {
        //find driver leave this try catch alone
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            System.err.println(e.getMessage());
        }

        try { //try different functions here
            Connection conn = DriverManager.getConnection("jdbc:mysql://35.223.224.130:3306/minaj", user, pass);//connect to db

            System.out.println("GET EMPLOYEES FXN: " + DatabaseQueries.getEmployees(conn)); // [Employee ID, FirstName, LastName, PhoneNumber, Email, Position, Address, UserID]
            System.out.println("GET INVENTORY FXN: " + DatabaseQueries.getInventory(conn)); //[ItemID, ItemName, Count]
            System.out.println("GET EVENTS FXN: " + DatabaseQueries.getEvents(conn, 1)); // [Name, Description, DateTime, UserID]
            System.out.println("GET TIME FXN: " + DatabaseQueries.getTime(conn, 1)); // [Date, StartTime, EndTime, EmployeeID]
            System.out.println("GET USERS FXN: " + DatabaseQueries.getUsers(conn, 1)); //[UserID, Username, Password, Email, isEmployee]

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        launch(args);
    }
}
