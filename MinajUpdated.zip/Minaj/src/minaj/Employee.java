package minaj;

public class Employee {
    private int id = -1;
    private String firstName = null;
    private String lastName = null;
    private String phoneNumber = null;
    private String email = null;
    private String position = null;
    private String address = null;

    public Employee(int id, String firstName, String lastName, String phoneNumber, String email, String position, String address) {
       this.id = id;
       this.firstName = firstName;
       this.lastName = lastName;
       this.phoneNumber = phoneNumber;
       this.email = email;
       this.position = position;
       this.address = address;
    }

    public int getId() {
       return id;
    } 

    public String getFirstName() {
       return firstName;
    }

    public String getLastName() {
       return lastName;
    }

    public String getPhoneNumber() {
       return phoneNumber;
    } 

    public String getEmail() {
       return email;
    }

    public String getPosition() {
        return position;
    }

    public String getAddress() {
       return address;
    }

 }